from menu import Menu, MenuItem
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine

coffeemaker = CoffeeMaker()
coffeemenu = Menu()
moneymech = MoneyMachine()

continue_ordering = True

while continue_ordering:
    usr_ipt = input(f"What would you like? ({coffeemenu.get_items()}): ").lower()

    if usr_ipt == 'report':
        coffeemaker.report()
        moneymech.report()
    elif coffeemenu.find_drink(usr_ipt).name == usr_ipt:
        if coffeemaker.is_resource_sufficient(coffeemenu.find_drink(usr_ipt)):
            if moneymech.make_payment(coffeemenu.find_drink(usr_ipt).cost):
                coffeemaker.make_coffee(coffeemenu.find_drink(usr_ipt))
    else:
        continue_ordering = False

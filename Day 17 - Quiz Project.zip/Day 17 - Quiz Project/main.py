class User:
    def __init__(self, user_id, username):
        print("new user created")
        self.id = user_id
        self.uname = username


user1 = User("001", "Tsunade")
print(user1.id, user1.uname)
print(user1)

user2 = User("002", "Mitsuku")
print(user2.id, user2.uname)


class Question:
    def __init__(self, text, answer):
        self.text = text
        self.answer = answer


# newq = Question("5+3 = 8", "True")
# print(newq.txt, newq.ans)

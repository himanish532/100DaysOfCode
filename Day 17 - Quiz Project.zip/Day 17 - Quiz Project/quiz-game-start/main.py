from question_model import Question
from data import question_data
from quiz_brain import QuizBrain

question_bank = []
length = len(question_data)

for i in range(0, length):
    que = Question(question_data[i]["text"], question_data[i]["answer"])
    question_bank.append(que)

quiz = QuizBrain(question_bank)

while quiz.still_has_question(length):
    quiz.next_question()


quiz.quiz_completed()

